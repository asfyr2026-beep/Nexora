package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.localization.AppLanguage
import com.example.localization.LocalAppLanguage
import com.example.localization.NexoraStrings
import com.example.ui.NexoraViewModel
import com.example.ui.ScreenDestination
import com.example.ui.components.ApiKeyDialog
import com.example.ui.components.AppTopBar
import com.example.ui.components.NexoraDrawerContent
import com.example.ui.screens.*
import com.example.ui.theme.NexoraTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: NexoraViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
            val language by viewModel.language.collectAsStateWithLifecycle()
            val showApiKeyDialog by viewModel.showApiKeyDialog.collectAsStateWithLifecycle()

            val tasks by viewModel.allTasks.collectAsStateWithLifecycle(initialValue = emptyList())
            val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
            val isChatLoading by viewModel.isChatLoading.collectAsStateWithLifecycle()

            val studyResult by viewModel.studyResultText.collectAsStateWithLifecycle()
            val flashcards by viewModel.flashcards.collectAsStateWithLifecycle()
            val isStudyLoading by viewModel.isStudyLoading.collectAsStateWithLifecycle()

            val translatedText by viewModel.translatedText.collectAsStateWithLifecycle()
            val isTranslating by viewModel.isTranslating.collectAsStateWithLifecycle()

            val writingOutput by viewModel.writingOutput.collectAsStateWithLifecycle()
            val isWritingLoading by viewModel.isWritingLoading.collectAsStateWithLifecycle()

            val imageBase64 by viewModel.imageOutputBase64.collectAsStateWithLifecycle()
            val imageStatus by viewModel.imageStatusText.collectAsStateWithLifecycle()
            val isImageLoading by viewModel.isImageLoading.collectAsStateWithLifecycle()

            val codingOutput by viewModel.codingOutput.collectAsStateWithLifecycle()
            val isCodingLoading by viewModel.isCodingLoading.collectAsStateWithLifecycle()

            val snackbarHostState = remember { SnackbarHostState() }
            val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
            val scope = rememberCoroutineScope()

            var initialChatPrompt by remember { mutableStateOf<String?>(null) }

            // Listen for toast/snackbar events
            LaunchedEffect(Unit) {
                viewModel.toastEvent.collect { message ->
                    snackbarHostState.showSnackbar(message)
                }
            }

            // Handle back press
            BackHandler(enabled = currentScreen != ScreenDestination.LANDING) {
                if (drawerState.isOpen) {
                    scope.launch { drawerState.close() }
                } else {
                    viewModel.navigateTo(ScreenDestination.LANDING)
                }
            }

            CompositionLocalProvider(
                LocalLayoutDirection provides language.layoutDirection,
                LocalAppLanguage provides language
            ) {
                NexoraTheme {
                    ModalNavigationDrawer(
                        drawerState = drawerState,
                        drawerContent = {
                            ModalDrawerSheet(
                                drawerContainerColor = com.example.ui.theme.NexoraDarkBg
                            ) {
                                NexoraDrawerContent(
                                    currentDestination = currentScreen,
                                    language = language,
                                    isApiKeyConfigured = viewModel.isApiKeyConfigured,
                                    onNavigate = { dest ->
                                        viewModel.navigateTo(dest)
                                    },
                                    onCloseDrawer = {
                                        scope.launch { drawerState.close() }
                                    }
                                )
                            }
                        }
                    ) {
                        Scaffold(
                            modifier = Modifier.fillMaxSize(),
                            snackbarHost = { SnackbarHost(snackbarHostState) },
                            topBar = {
                                val title = when (currentScreen) {
                                    ScreenDestination.LANDING -> NexoraStrings.appName(language)
                                    ScreenDestination.CHAT -> NexoraStrings.navChat(language)
                                    ScreenDestination.STUDY -> NexoraStrings.navStudy(language)
                                    ScreenDestination.TRANSLATION -> NexoraStrings.navTranslate(language)
                                    ScreenDestination.WRITING -> NexoraStrings.navWriting(language)
                                    ScreenDestination.IMAGE -> NexoraStrings.navImage(language)
                                    ScreenDestination.CODING -> NexoraStrings.navCoding(language)
                                    ScreenDestination.TASKS -> NexoraStrings.navTasks(language)
                                }

                                AppTopBar(
                                    title = title,
                                    currentLanguage = language,
                                    isApiKeyConfigured = viewModel.isApiKeyConfigured,
                                    onMenuClick = {
                                        scope.launch {
                                            if (drawerState.isOpen) drawerState.close() else drawerState.open()
                                        }
                                    },
                                    onLanguageToggle = { viewModel.toggleLanguage() },
                                    onApiKeyClick = { viewModel.setShowApiKeyDialog(true) }
                                )
                            }
                        ) { innerPadding ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                            ) {
                                when (currentScreen) {
                                    ScreenDestination.LANDING -> LandingScreen(
                                        language = language,
                                        isApiKeyConfigured = viewModel.isApiKeyConfigured,
                                        onNavigate = { dest -> viewModel.navigateTo(dest) },
                                        onQuickPrompt = { prompt ->
                                            initialChatPrompt = prompt
                                            viewModel.navigateTo(ScreenDestination.CHAT)
                                        }
                                    )

                                    ScreenDestination.CHAT -> ChatScreen(
                                        messages = chatMessages,
                                        isLoading = isChatLoading,
                                        isApiKeyConfigured = viewModel.isApiKeyConfigured,
                                        language = language,
                                        initialPrompt = initialChatPrompt,
                                        onSendMessage = { prompt ->
                                            initialChatPrompt = null
                                            viewModel.sendChatMessage(prompt)
                                        },
                                        onClearChat = { viewModel.clearChat() },
                                        onOpenApiKeyDialog = { viewModel.setShowApiKeyDialog(true) }
                                    )

                                    ScreenDestination.STUDY -> StudyScreen(
                                        studyResult = studyResult,
                                        flashcards = flashcards,
                                        isLoading = isStudyLoading,
                                        language = language,
                                        onRunStudy = { topic, mode ->
                                            viewModel.runStudyAssistant(topic, mode)
                                        }
                                    )

                                    ScreenDestination.TRANSLATION -> TranslationScreen(
                                        translatedText = translatedText,
                                        isTranslating = isTranslating,
                                        language = language,
                                        onTranslate = { text, from, to, tone ->
                                            viewModel.translate(text, from, to, tone)
                                        }
                                    )

                                    ScreenDestination.WRITING -> WritingScreen(
                                        writingOutput = writingOutput,
                                        isLoading = isWritingLoading,
                                        language = language,
                                        onGenerate = { topic, format, tone, audience ->
                                            viewModel.generateWriting(topic, format, tone, audience)
                                        }
                                    )

                                    ScreenDestination.IMAGE -> ImageScreen(
                                        imageBase64 = imageBase64,
                                        statusText = imageStatus,
                                        isLoading = isImageLoading,
                                        language = language,
                                        onGenerateImage = { prompt, style, ratio ->
                                            viewModel.generateImage(prompt, style, ratio)
                                        }
                                    )

                                    ScreenDestination.CODING -> CodingScreen(
                                        codingOutput = codingOutput,
                                        isLoading = isCodingLoading,
                                        language = language,
                                        onRunCodeAction = { code, lang, action ->
                                            viewModel.runCodingAssistant(code, lang, action)
                                        }
                                    )

                                    ScreenDestination.TASKS -> TaskScreen(
                                        tasks = tasks,
                                        language = language,
                                        onAddTask = { title, desc, cat, prio, due ->
                                            viewModel.addTask(title, desc, cat, prio, due)
                                        },
                                        onToggleTask = { task ->
                                            viewModel.toggleTaskCompletion(task)
                                        },
                                        onDeleteTask = { task ->
                                            viewModel.deleteTask(task)
                                        },
                                        onClearCompleted = {
                                            viewModel.clearCompletedTasks()
                                        }
                                    )
                                }
                            }
                        }

                        // API Key Information Dialog
                        ApiKeyDialog(
                            isOpen = showApiKeyDialog,
                            isKeyConfigured = viewModel.isApiKeyConfigured,
                            language = language,
                            onDismiss = { viewModel.setShowApiKeyDialog(false) }
                        )
                    }
                }
            }
        }
    }
}
