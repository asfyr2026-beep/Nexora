package com.example.data.api

import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

object GeminiApiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/"

    val isKeyConfigured: Boolean
        get() {
            val key = BuildConfig.GEMINI_API_KEY
            return key.isNotBlank() &&
                    key != "MY_GEMINI_API_KEY" &&
                    !key.contains("PLACEHOLDER", ignoreCase = true)
        }

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun generateContent(
        prompt: String,
        systemInstruction: String? = null,
        model: String = "gemini-3.5-flash"
    ): AIResult = withContext(Dispatchers.IO) {
        if (!isKeyConfigured) {
            return@withContext AIResult.MissingApiKey
        }

        val apiKey = BuildConfig.GEMINI_API_KEY
        val url = "$BASE_URL$model:generateContent?key=$apiKey"

        val requestPayload = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    role = "user",
                    parts = listOf(GeminiPart(text = prompt))
                )
            ),
            systemInstruction = systemInstruction?.let {
                GeminiContent(parts = listOf(GeminiPart(text = it)))
            }
        )

        try {
            val jsonAdapter = moshi.adapter(GeminiRequest::class.java)
            val jsonBody = jsonAdapter.toJson(requestPayload)
            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    val errAdapter = moshi.adapter(GeminiResponse::class.java)
                    val errResponse = runCatching { errAdapter.fromJson(bodyString) }.getOrNull()
                    val msg = errResponse?.error?.message ?: "HTTP Error ${response.code}: ${response.message}"
                    return@withContext AIResult.Error(msg)
                }

                val responseAdapter = moshi.adapter(GeminiResponse::class.java)
                val geminiResponse = responseAdapter.fromJson(bodyString)
                val textCandidate = geminiResponse?.candidates
                    ?.firstOrNull()?.content?.parts?.firstOrNull()?.text

                if (!textCandidate.isNullOrBlank()) {
                    AIResult.Success(text = textCandidate)
                } else {
                    AIResult.Error("No textual response returned by Gemini engine.")
                }
            }
        } catch (e: Exception) {
            AIResult.Error(e.localizedMessage ?: "Unknown network exception occurred.")
        }
    }

    suspend fun generateChat(
        history: List<Pair<String, String>>, // role ("user" or "model") to text
        userMessage: String,
        systemInstruction: String? = null,
        model: String = "gemini-3.5-flash"
    ): AIResult = withContext(Dispatchers.IO) {
        if (!isKeyConfigured) {
            return@withContext AIResult.MissingApiKey
        }

        val apiKey = BuildConfig.GEMINI_API_KEY
        val url = "$BASE_URL$model:generateContent?key=$apiKey"

        val contents = mutableListOf<GeminiContent>()
        // Keep recent context (up to 12 turns) to stay within token limits and maintain low latency
        val recentHistory = history.takeLast(12)
        for ((role, text) in recentHistory) {
            contents.add(
                GeminiContent(
                    role = if (role == "user") "user" else "model",
                    parts = listOf(GeminiPart(text = text))
                )
            )
        }
        contents.add(
            GeminiContent(
                role = "user",
                parts = listOf(GeminiPart(text = userMessage))
            )
        )

        val requestPayload = GeminiRequest(
            contents = contents,
            systemInstruction = systemInstruction?.let {
                GeminiContent(parts = listOf(GeminiPart(text = it)))
            }
        )

        try {
            val jsonAdapter = moshi.adapter(GeminiRequest::class.java)
            val jsonBody = jsonAdapter.toJson(requestPayload)
            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    val errAdapter = moshi.adapter(GeminiResponse::class.java)
                    val errResponse = runCatching { errAdapter.fromJson(bodyString) }.getOrNull()
                    val msg = errResponse?.error?.message ?: "HTTP Error ${response.code}"
                    return@withContext AIResult.Error(msg)
                }

                val responseAdapter = moshi.adapter(GeminiResponse::class.java)
                val geminiResponse = responseAdapter.fromJson(bodyString)
                val textCandidate = geminiResponse?.candidates
                    ?.firstOrNull()?.content?.parts?.firstOrNull()?.text

                if (!textCandidate.isNullOrBlank()) {
                    AIResult.Success(text = textCandidate)
                } else {
                    AIResult.Error("No response content received.")
                }
            }
        } catch (e: Exception) {
            AIResult.Error(e.localizedMessage ?: "Network connection error")
        }
    }

    suspend fun generateImage(
        prompt: String,
        aspectRatio: String = "1:1",
        imageSize: String = "1K"
    ): AIResult = withContext(Dispatchers.IO) {
        if (!isKeyConfigured) {
            return@withContext AIResult.MissingApiKey
        }

        val apiKey = BuildConfig.GEMINI_API_KEY
        val model = "gemini-2.5-flash-image"
        val url = "$BASE_URL$model:generateContent?key=$apiKey"

        val requestPayload = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    parts = listOf(GeminiPart(text = prompt))
                )
            ),
            generationConfig = GeminiGenerationConfig(
                responseModalities = listOf("TEXT", "IMAGE"),
                imageConfig = GeminiImageConfig(aspectRatio = aspectRatio, imageSize = imageSize)
            )
        )

        try {
            val jsonAdapter = moshi.adapter(GeminiRequest::class.java)
            val jsonBody = jsonAdapter.toJson(requestPayload)
            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    val errAdapter = moshi.adapter(GeminiResponse::class.java)
                    val errResponse = runCatching { errAdapter.fromJson(bodyString) }.getOrNull()
                    return@withContext AIResult.Error(errResponse?.error?.message ?: "Image generation failed (HTTP ${response.code})")
                }

                val responseAdapter = moshi.adapter(GeminiResponse::class.java)
                val geminiResponse = responseAdapter.fromJson(bodyString)
                val parts = geminiResponse?.candidates?.firstOrNull()?.content?.parts

                var base64Data: String? = null
                var textDesc: String? = null

                parts?.forEach { part ->
                    if (part.inlineData != null) {
                        base64Data = part.inlineData.data
                    }
                    if (!part.text.isNullOrBlank()) {
                        textDesc = part.text
                    }
                }

                if (base64Data != null) {
                    AIResult.Success(text = textDesc ?: "Image generated successfully", imageBase64 = base64Data)
                } else if (!textDesc.isNullOrBlank()) {
                    AIResult.Success(text = textDesc!!)
                } else {
                    AIResult.Error("No image data returned from Gemini.")
                }
            }
        } catch (e: Exception) {
            AIResult.Error(e.localizedMessage ?: "Image generation network error")
        }
    }
}
