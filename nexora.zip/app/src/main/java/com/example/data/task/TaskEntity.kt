package com.example.data.task

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "nexora_tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val category: String = "General", // Study, Code, Writing, General, Work
    val priority: String = "Medium", // High, Medium, Low
    val dueDate: String = "",
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
