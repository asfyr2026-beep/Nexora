package com.example.localization

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.LayoutDirection

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String, val layoutDirection: LayoutDirection) {
    ENGLISH("en", "English", "English (LTR)", LayoutDirection.Ltr),
    ARABIC("ar", "Arabic", "العربية (RTL)", LayoutDirection.Rtl)
}

val LocalAppLanguage = compositionLocalOf { AppLanguage.ENGLISH }

object NexoraStrings {
    fun appName(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Nexora"
        AppLanguage.ARABIC -> "نيكسورا"
    }

    fun appTagline(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Next-Generation Intelligence Platform"
        AppLanguage.ARABIC -> "منصة الذكاء الاصطناعي من الجيل الجديد"
    }

    fun navOverview(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Overview"
        AppLanguage.ARABIC -> "الرئيسية"
    }

    fun navChat(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "AI Chat"
        AppLanguage.ARABIC -> "المحادثة"
    }

    fun navStudy(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Study Helper"
        AppLanguage.ARABIC -> "المساعد الدراسي"
    }

    fun navTranslate(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Smart Translate"
        AppLanguage.ARABIC -> "الترجمة الذكية"
    }

    fun navWriting(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Writing Studio"
        AppLanguage.ARABIC -> "استوديو الكتابة"
    }

    fun navImage(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Image Studio"
        AppLanguage.ARABIC -> "استوديو الصور"
    }

    fun navCoding(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Code Assistant"
        AppLanguage.ARABIC -> "مساعد البرمجة"
    }

    fun navTasks(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Tasks"
        AppLanguage.ARABIC -> "إدارة المهام"
    }

    // Common Actions
    fun send(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Send"
        AppLanguage.ARABIC -> "إرسال"
    }

    fun clear(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Clear"
        AppLanguage.ARABIC -> "مسح"
    }

    fun copy(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Copy"
        AppLanguage.ARABIC -> "نسخ"
    }

    fun copied(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Copied to clipboard!"
        AppLanguage.ARABIC -> "تم النسخ إلى الحافظة!"
    }

    fun generate(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Generate"
        AppLanguage.ARABIC -> "توليد"
    }

    fun processing(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Synthesizing with Gemini..."
        AppLanguage.ARABIC -> "جارِ المعالجة بواسطة Gemini..."
    }

    fun apiKeyRequiredTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Gemini API Key Required"
        AppLanguage.ARABIC -> "مطلوب مفتاح Gemini API"
    }

    fun apiKeyRequiredMsg(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "To prevent fake responses and deliver authentic AI results, please configure your GEMINI_API_KEY in the AI Studio Secrets panel or .env file."
        AppLanguage.ARABIC -> "لتجنب الردود الوهمية وتقديم ذكاء اصطناعي حقيقي وموثوق، يرجى ضبط مفتاح GEMINI_API_KEY في لوحة أسرار AI Studio أو ملف .env."
    }

    fun apiKeyStatusLive(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Gemini Live API Active"
        AppLanguage.ARABIC -> "اتصال Gemini نشط ومباشر"
    }

    fun apiKeyStatusMissing(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "API Key Setup Needed"
        AppLanguage.ARABIC -> "يلزم إعداد مفتاح API"
    }

    fun openSetupGuide(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Setup Info"
        AppLanguage.ARABIC -> "دليل الإعداد"
    }

    // Landing Page
    fun heroBadge(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "NEXORA ENTERPRISE AI SUITE"
        AppLanguage.ARABIC -> "حزمة نيكسورا الذكية المتطورة"
    }

    fun heroHeadline(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Supercharge your intellect & workflow."
        AppLanguage.ARABIC -> "طوّر قدراتك الإبداعية والمهنية بقوة الذكاء الاصطناعي."
    }

    fun heroSub(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "All-in-one cognitive workstation powered by modern Gemini models. Seamless bilingual English and Arabic capabilities."
        AppLanguage.ARABIC -> "بيئة عمل متكاملة مدعومة بأحدث نماذج Gemini، مع دعم أصيل وتفاعلي ثنائي اللغة للعربية والإنجليزية."
    }

    fun quickPromptsTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Quick Start Prompts"
        AppLanguage.ARABIC -> "أوامر سريعة للبدء"
    }

    fun modulesTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Specialized AI Engines"
        AppLanguage.ARABIC -> "محركات الذكاء الاصطناعي المتخصصة"
    }

    // Chat
    fun chatPlaceholder(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Ask Nexora anything... (e.g. quantum physics, strategy, poetry)"
        AppLanguage.ARABIC -> "اسأل نيكسورا أي شيء... (مثل: الفيزياء الكمية، خطة عمل، قصيدة)"
    }

    fun chatWelcome(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Hello! I am Nexora, your AI companion. How can I assist you today?"
        AppLanguage.ARABIC -> "مرحباً بك! أنا نيكسورا، رفيقك الذكي. كيف يمكنني مساعدتك اليوم؟"
    }

    // Study
    fun studyTopicPlaceholder(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Enter study topic, chapter text, or complex concept..."
        AppLanguage.ARABIC -> "أدخل موضوع الدراسة، النص، أو المفهوم المعقد..."
    }

    fun studyFlashcardsTab(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Flashcards"
        AppLanguage.ARABIC -> "بطاقات استذكار"
    }

    fun studySummaryTab(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Executive Summary"
        AppLanguage.ARABIC -> "ملخص تنفيذي"
    }

    fun studyQuizTab(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Practice Quiz"
        AppLanguage.ARABIC -> "اختبار تدريبي"
    }

    fun studyExplainTab(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Deep Dive"
        AppLanguage.ARABIC -> "شرح مبسط وعميق"
    }

    // Translation
    fun translateSourcePlaceholder(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Enter text to translate..."
        AppLanguage.ARABIC -> "أدخل النص المراد ترجمته..."
    }

    fun translateResult(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Translation output"
        AppLanguage.ARABIC -> "نتيجة الترجمة"
    }

    fun swapLanguages(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Swap Languages"
        AppLanguage.ARABIC -> "تبديل اللغات"
    }

    // Writing
    fun writingTopicPlaceholder(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Describe the topic or paste existing text to refine..."
        AppLanguage.ARABIC -> "صف الموضوع أو الصق نصاً موجوداً لتحسينه وتطويره..."
    }

    // Coding
    fun codePromptPlaceholder(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Paste your code snippet or describe the algorithm you want to build..."
        AppLanguage.ARABIC -> "الصق الكود البرمجي أو صف الخوارزمية التي ترغب في برمجتها..."
    }

    // Image
    fun imagePromptPlaceholder(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Describe the scene to generate (e.g. Cyberpunk library at midnight)..."
        AppLanguage.ARABIC -> "صف المشهد المراد توليده (مثلاً: مكتبة سايبربانك خيالية في منتصف الليل)..."
    }

    // Tasks
    fun addTask(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Add Task"
        AppLanguage.ARABIC -> "إضافة مهمة"
    }

    fun taskTitlePlaceholder(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Task title..."
        AppLanguage.ARABIC -> "عنوان المهمة..."
    }

    fun taskDescPlaceholder(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Description or subtasks..."
        AppLanguage.ARABIC -> "الوصف أو المهام الفرعية..."
    }

    fun filterAll(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "All"
        AppLanguage.ARABIC -> "الكل"
    }

    fun filterActive(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Active"
        AppLanguage.ARABIC -> "قيد التنفيذ"
    }

    fun filterDone(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Done"
        AppLanguage.ARABIC -> "المكتملة"
    }
}
