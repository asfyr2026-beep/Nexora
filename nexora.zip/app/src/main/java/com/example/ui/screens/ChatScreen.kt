package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.NexoraStrings
import com.example.ui.ChatMessage
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(
    messages: List<ChatMessage>,
    isLoading: Boolean,
    isApiKeyConfigured: Boolean,
    language: AppLanguage,
    initialPrompt: String? = null,
    onSendMessage: (String) -> Unit,
    onClearChat: () -> Unit,
    onOpenApiKeyDialog: () -> Unit
) {
    val isAr = language == AppLanguage.ARABIC
    val context = LocalContext.current
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    var inputText by remember { mutableStateOf(initialPrompt ?: "") }

    LaunchedEffect(initialPrompt) {
        if (!initialPrompt.isNullOrBlank()) {
            inputText = initialPrompt
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val suggestions = if (isAr) listOf(
        "اشرح الحوسبة السحابية للمبتدئين",
        "حلل أثر الذكاء الاصطناعي في الطب",
        "صمم استراتيجية تسويق رقمي",
        "اقترح أفكار مشاريع برمجية جديدة"
    ) else listOf(
        "Explain cloud architecture simply",
        "Analyze AI impact on modern medicine",
        "Design a go-to-market strategy",
        "Suggest novel software project ideas"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NexoraDarkBg)
    ) {
        // Missing API Key Banner if not set
        if (!isApiKeyConfigured) {
            Surface(
                color = Color(0x33F59E0B),
                border = androidx.compose.foundation.BorderStroke(1.dp, NexoraAmber.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onOpenApiKeyDialog() }
                    .testTag("chat_api_warning_banner")
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = NexoraAmber,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = if (isAr)
                            "مفتاح Gemini API غير مهيأ. تم إيقاف الردود الوهمية لضمان المصداقية. انقر هنا للإعداد."
                        else
                            "Gemini API key required. Simulated replies disabled for authenticity. Tap to configure.",
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextPrimary),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Header controls (Clear Chat)
        if (messages.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = onClearChat,
                    colors = ButtonDefaults.textButtonColors(contentColor = NexoraTextSecondary),
                    modifier = Modifier.testTag("clear_chat_button")
                ) {
                    Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(NexoraStrings.clear(language), fontSize = 12.sp)
                }
            }
        }

        // Chat Messages Area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (messages.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                Brush.linearGradient(listOf(NexoraBluePrimary, NexoraPurpleSecondary))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChatBubble,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = NexoraStrings.chatWelcome(language),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        ),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (isAr)
                            "أنا جاهز للإجابة، البرمجة، التحليل، والترجمة بدقة فائقة."
                        else
                            "Ready to reason, calculate, code, and assist across complex tasks.",
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Suggestion Pills
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(suggestions) { sugg ->
                            Surface(
                                color = NexoraSurfaceVariant,
                                shape = RoundedCornerShape(16.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable {
                                        inputText = sugg
                                        onSendMessage(sugg)
                                    }
                            ) {
                                Text(
                                    text = sugg,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = NexoraBlueGlow,
                                        fontWeight = FontWeight.Medium
                                    )
                                )
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        val isUser = msg.sender == "user"
                        ChatBubble(
                            message = msg,
                            isUser = isUser,
                            onCopy = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Nexora AI Message", msg.text)
                                clipboard.setPrimaryClip(clip)
                            }
                        )
                    }

                    if (isLoading) {
                        item {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(8.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = NexoraPurpleGlow,
                                    strokeWidth = 2.dp
                                )
                                Text(
                                    text = NexoraStrings.processing(language),
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = NexoraPurpleGlow,
                                        fontWeight = FontWeight.Medium
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Input Bar
        Surface(
            color = NexoraSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = {
                        Text(
                            text = NexoraStrings.chatPlaceholder(language),
                            style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field"),
                    maxLines = 4,
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = NexoraSurfaceVariant,
                        unfocusedContainerColor = NexoraSurfaceVariant,
                        focusedBorderColor = NexoraBluePrimary,
                        unfocusedBorderColor = NexoraCardBorder,
                        focusedTextColor = NexoraTextPrimary,
                        unfocusedTextColor = NexoraTextPrimary
                    )
                )

                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            val promptToSend = inputText
                            inputText = ""
                            onSendMessage(promptToSend)
                        }
                    },
                    enabled = inputText.isNotBlank() && !isLoading,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            if (inputText.isNotBlank() && !isLoading)
                                Brush.linearGradient(listOf(NexoraBluePrimary, NexoraPurpleSecondary))
                            else
                                Brush.linearGradient(listOf(NexoraSurfaceVariant, NexoraSurfaceVariant))
                        )
                        .testTag("chat_send_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = NexoraStrings.send(language),
                        tint = if (inputText.isNotBlank() && !isLoading) Color.White else NexoraTextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ChatBubble(
    message: ChatMessage,
    isUser: Boolean,
    onCopy: () -> Unit
) {
    var showCopied by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(bottom = 2.dp)
        ) {
            Text(
                text = if (isUser) "You" else "Nexora AI",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isUser) NexoraBlueGlow else NexoraPurpleGlow,
                    fontSize = 11.sp
                )
            )
        }

        Surface(
            color = if (isUser) NexoraBlueContainer else NexoraSurfaceVariant,
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isUser) NexoraBluePrimary.copy(alpha = 0.5f) else NexoraCardBorder
            ),
            modifier = Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = NexoraTextPrimary,
                        lineHeight = 22.sp
                    )
                )

                if (!isUser) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        IconButton(
                            onClick = {
                                onCopy()
                                showCopied = true
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = if (showCopied) Icons.Default.Check else Icons.Default.ContentCopy,
                                contentDescription = "Copy Response",
                                tint = if (showCopied) NexoraEmerald else NexoraTextMuted,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
