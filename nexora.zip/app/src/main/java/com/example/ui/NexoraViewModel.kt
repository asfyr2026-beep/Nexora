package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.AIResult
import com.example.data.api.GeminiApiClient
import com.example.data.task.TaskDatabase
import com.example.data.task.TaskEntity
import com.example.localization.AppLanguage
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class ScreenDestination {
    LANDING,
    CHAT,
    STUDY,
    TRANSLATION,
    WRITING,
    IMAGE,
    CODING,
    TASKS
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String, // "user" or "model"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class FlashCardItem(
    val question: String,
    val answer: String
)

data class QuizQuestion(
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

class NexoraViewModel(application: Application) : AndroidViewModel(application) {
    private val taskDao = TaskDatabase.getDatabase(application).taskDao()

    // Navigation & Global State
    private val _currentScreen = MutableStateFlow(ScreenDestination.LANDING)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    private val _language = MutableStateFlow(AppLanguage.ENGLISH)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    private val _showApiKeyDialog = MutableStateFlow(false)
    val showApiKeyDialog: StateFlow<Boolean> = _showApiKeyDialog.asStateFlow()

    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    val isApiKeyConfigured: Boolean
        get() = GeminiApiClient.isKeyConfigured

    // --- Task State ---
    val allTasks = taskDao.getAllTasks()

    // --- Chat State ---
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(listOf())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    // --- Study State ---
    private val _studyResultText = MutableStateFlow("")
    val studyResultText: StateFlow<String> = _studyResultText.asStateFlow()

    private val _isStudyLoading = MutableStateFlow(false)
    val isStudyLoading: StateFlow<Boolean> = _isStudyLoading.asStateFlow()

    private val _flashcards = MutableStateFlow<List<FlashCardItem>>(emptyList())
    val flashcards: StateFlow<List<FlashCardItem>> = _flashcards.asStateFlow()

    private val _quizQuestions = MutableStateFlow<List<QuizQuestion>>(emptyList())
    val quizQuestions: StateFlow<List<QuizQuestion>> = _quizQuestions.asStateFlow()

    // --- Translation State ---
    private val _translatedText = MutableStateFlow("")
    val translatedText: StateFlow<String> = _translatedText.asStateFlow()

    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    // --- Writing State ---
    private val _writingOutput = MutableStateFlow("")
    val writingOutput: StateFlow<String> = _writingOutput.asStateFlow()

    private val _isWritingLoading = MutableStateFlow(false)
    val isWritingLoading: StateFlow<Boolean> = _isWritingLoading.asStateFlow()

    // --- Image State ---
    private val _imageOutputBase64 = MutableStateFlow<String?>(null)
    val imageOutputBase64: StateFlow<String?> = _imageOutputBase64.asStateFlow()

    private val _imageStatusText = MutableStateFlow("")
    val imageStatusText: StateFlow<String> = _imageStatusText.asStateFlow()

    private val _isImageLoading = MutableStateFlow(false)
    val isImageLoading: StateFlow<Boolean> = _isImageLoading.asStateFlow()

    // --- Coding State ---
    private val _codingOutput = MutableStateFlow("")
    val codingOutput: StateFlow<String> = _codingOutput.asStateFlow()

    private val _isCodingLoading = MutableStateFlow(false)
    val isCodingLoading: StateFlow<Boolean> = _isCodingLoading.asStateFlow()

    fun navigateTo(destination: ScreenDestination) {
        _currentScreen.value = destination
    }

    fun toggleLanguage() {
        _language.value = if (_language.value == AppLanguage.ENGLISH) AppLanguage.ARABIC else AppLanguage.ENGLISH
    }

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
    }

    fun setShowApiKeyDialog(show: Boolean) {
        _showApiKeyDialog.value = show
    }

    fun sendToast(msg: String) {
        viewModelScope.launch {
            _toastEvent.emit(msg)
        }
    }

    // --- Task Actions ---
    fun addTask(title: String, description: String, category: String, priority: String, dueDate: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            taskDao.insertTask(
                TaskEntity(
                    title = title.trim(),
                    description = description.trim(),
                    category = category,
                    priority = priority,
                    dueDate = dueDate
                )
            )
            sendToast(if (_language.value == AppLanguage.ARABIC) "تمت إضافة المهمة بنجاح" else "Task created successfully")
        }
    }

    fun toggleTaskCompletion(task: TaskEntity) {
        viewModelScope.launch {
            taskDao.updateTask(task.copy(isCompleted = !task.isCompleted))
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            taskDao.deleteTask(task)
            sendToast(if (_language.value == AppLanguage.ARABIC) "تم حذف المهمة" else "Task deleted")
        }
    }

    fun clearCompletedTasks() {
        viewModelScope.launch {
            taskDao.deleteCompletedTasks()
            sendToast(if (_language.value == AppLanguage.ARABIC) "تم تنظيف المهام المكتملة" else "Cleared completed tasks")
        }
    }

    // --- Chat Actions ---
    fun sendChatMessage(prompt: String) {
        if (prompt.isBlank()) return
        val userMsg = ChatMessage(sender = "user", text = prompt.trim())
        _chatMessages.value = _chatMessages.value + userMsg

        if (!isApiKeyConfigured) {
            _chatMessages.value = _chatMessages.value + ChatMessage(
                sender = "model",
                text = if (_language.value == AppLanguage.ARABIC)
                    "⚠️ [مطلوب مفتاح Gemini API]: تم تعطيل الردود الوهمية لضمان الدقة والمصداقية. يرجى تهيئة GEMINI_API_KEY في لوحة الأسرار (Secrets) لتفعيل ردود الذكاء الاصطناعي الحية."
                else
                    "⚠️ [Gemini API Key Required]: Real-time AI processing requires an active GEMINI_API_KEY. To maintain authenticity, simulated fake replies are disabled. Please configure your key in the AI Studio Secrets panel."
            )
            return
        }

        viewModelScope.launch {
            _isChatLoading.value = true
            val history = _chatMessages.value.dropLast(1).map { it.sender to it.text }
            val systemPrompt = "You are Nexora, a world-class, ultra-capable AI assistant. Provide thoughtful, accurate, beautifully structured answers. If the user writes in Arabic, respond in fluent, professional, articulate Arabic. If in English, respond in articulate English."
            when (val result = GeminiApiClient.generateChat(history, prompt, systemInstruction = systemPrompt)) {
                is AIResult.Success -> {
                    _chatMessages.value = _chatMessages.value + ChatMessage(sender = "model", text = result.text)
                }
                is AIResult.MissingApiKey -> {
                    _chatMessages.value = _chatMessages.value + ChatMessage(
                        sender = "model",
                        text = if (_language.value == AppLanguage.ARABIC) "مفتاح API غير متوفر." else "API Key is missing."
                    )
                }
                is AIResult.Error -> {
                    _chatMessages.value = _chatMessages.value + ChatMessage(
                        sender = "model",
                        text = "Error: ${result.message}"
                    )
                }
            }
            _isChatLoading.value = false
        }
    }

    fun clearChat() {
        _chatMessages.value = emptyList()
    }

    // --- Study Actions ---
    fun runStudyAssistant(topic: String, mode: String) {
        if (topic.isBlank()) return
        if (!isApiKeyConfigured) {
            _studyResultText.value = if (_language.value == AppLanguage.ARABIC)
                "⚠️ يلزم مفتاح Gemini API لتحليل وإنشاء المواد الدراسية. يرجى تهيئة المفتاح في لوحة الأسرار."
            else
                "⚠️ Gemini API Key is required to analyze and generate study materials. Please configure your key in Secrets."
            return
        }

        viewModelScope.launch {
            _isStudyLoading.value = true
            val isAr = _language.value == AppLanguage.ARABIC
            val prompt = when (mode) {
                "flashcards" -> if (isAr)
                    "قم بإنشاء 5 بطاقات استذكار تعليمية قوية ومفصلة حول الموضوع التالي: $topic. نسّق كل بطاقة بدقة على الشكل: Q: السؤال | A: الجواب"
                else
                    "Create 5 high-yield study flashcards for: $topic. Format each flashcard strictly as: Q: [Question] | A: [Answer]"

                "summary" -> if (isAr)
                    "قدم ملخصاً تنفيذياً شاملاً وواضحاً مع أهم النقاط الأساسية والمفاهيم الرئيسية حول: $topic"
                else
                    "Provide a comprehensive executive summary with key concepts, bulleted takeaways, and critical insights on: $topic"

                "quiz" -> if (isAr)
                    "قم بإنشاء اختبار تدريبي مكون من 3 أسئلة اختيار من متعدد حول: $topic. لكل سؤال ضع 4 خيارات وحدد الإجابة الصحيحة مع شرح مقتضب."
                else
                    "Generate a 3-question multiple-choice practice quiz on: $topic with 4 choices per question, the correct answer, and an explanation."

                else -> if (isAr)
                    "اشرح بعمق وبطريقة تفاعلية مبسطة المفهوم التالي: $topic مع أمثلة واقعية ومقارنات توضيحية."
                else
                    "Break down and deeply explain the concept: $topic using clear real-world analogies, core mechanisms, and intuitive examples."
            }

            when (val res = GeminiApiClient.generateContent(prompt, model = "gemini-3.5-flash")) {
                is AIResult.Success -> {
                    _studyResultText.value = res.text
                    if (mode == "flashcards") {
                        parseFlashcards(res.text)
                    }
                }
                is AIResult.MissingApiKey -> {
                    _studyResultText.value = "Gemini API key missing."
                }
                is AIResult.Error -> {
                    _studyResultText.value = "Error: ${res.message}"
                }
            }
            _isStudyLoading.value = false
        }
    }

    private fun parseFlashcards(raw: String) {
        val lines = raw.lines().filter { it.contains("Q:") && it.contains("A:") }
        val cards = lines.mapNotNull { line ->
            val parts = line.split("|")
            if (parts.size >= 2) {
                val q = parts[0].substringAfter("Q:").trim()
                val a = parts[1].substringAfter("A:").trim()
                FlashCardItem(question = q, answer = a)
            } else null
        }
        if (cards.isNotEmpty()) {
            _flashcards.value = cards
        }
    }

    // --- Translation Actions ---
    fun translate(text: String, from: String, to: String, tone: String) {
        if (text.isBlank()) return
        if (!isApiKeyConfigured) {
            _translatedText.value = if (_language.value == AppLanguage.ARABIC)
                "⚠️ يلزم مفتاح Gemini API لإجراء الترجمة الذكية. يرجى ضبط المفتاح في لوحة الأسرار."
            else
                "⚠️ Gemini API Key is required for contextual translation. Please configure your key in Secrets."
            return
        }

        viewModelScope.launch {
            _isTranslating.value = true
            val prompt = "Translate the following text from $from to $to using a $tone tone. Preserve cultural idioms, nuances, and technical correctness. Only return the translated text directly without conversational commentary.\n\nText:\n$text"
            when (val res = GeminiApiClient.generateContent(prompt, model = "gemini-3.5-flash")) {
                is AIResult.Success -> _translatedText.value = res.text.trim()
                is AIResult.MissingApiKey -> _translatedText.value = "API Key missing."
                is AIResult.Error -> _translatedText.value = "Translation error: ${res.message}"
            }
            _isTranslating.value = false
        }
    }

    // --- Writing Actions ---
    fun generateWriting(topic: String, format: String, tone: String, audience: String) {
        if (topic.isBlank()) return
        if (!isApiKeyConfigured) {
            _writingOutput.value = if (_language.value == AppLanguage.ARABIC)
                "⚠️ يلزم مفتاح Gemini API لتوليد النصوص وصياغتها. يرجى تهيئة المفتاح في لوحة الأسرار."
            else
                "⚠️ Gemini API Key is required to draft and polish copy. Please configure your key in Secrets."
            return
        }

        viewModelScope.launch {
            _isWritingLoading.value = true
            val isAr = _language.value == AppLanguage.ARABIC
            val prompt = if (isAr) {
                "أنت خبير صياغة وكتابة إبداعية وتنفيذية. اكتب محتوى بجودة استثنائية بصيغة '$format' بنبرة '$tone' وموجه لجمهور '$audience'.\n\nالموضوع أو النص:\n$topic"
            } else {
                "You are an executive writer and communications strategist. Produce a high-impact '$format' in a '$tone' tone tailored for '$audience'. Ensure impeccable structure, engaging flow, and polished diction.\n\nTopic / Input:\n$topic"
            }

            when (val res = GeminiApiClient.generateContent(prompt, model = "gemini-3.5-flash")) {
                is AIResult.Success -> _writingOutput.value = res.text
                is AIResult.MissingApiKey -> _writingOutput.value = "API key missing."
                is AIResult.Error -> _writingOutput.value = "Writing error: ${res.message}"
            }
            _isWritingLoading.value = false
        }
    }

    // --- Coding Actions ---
    fun runCodingAssistant(input: String, language: String, action: String) {
        if (input.isBlank()) return
        if (!isApiKeyConfigured) {
            _codingOutput.value = if (_language.value == AppLanguage.ARABIC)
                "⚠️ يلزم مفتاح Gemini API للمساعد البرمجي. يرجى ضبط المفتاح في لوحة الأسرار لتشغيل نموذج البرمجة المتقدم gemini-3.1-pro-preview."
            else
                "⚠️ Gemini API Key is required for the coding assistant. Please configure your key in Secrets to run the advanced gemini-3.1-pro-preview reasoning model."
            return
        }

        viewModelScope.launch {
            _isCodingLoading.value = true
            val prompt = when (action) {
                "explain" -> "Analyze and clearly explain the following $language code. Highlight architecture, potential edge-cases, and complexity:\n\n```$language\n$input\n```"
                "fix" -> "Find any bugs, performance bottlenecks, or security issues in this $language code. Provide the corrected, optimized code and explain what was fixed:\n\n```$language\n$input\n```"
                "generate" -> "Write clean, idiomatic, production-ready $language code for the following specification. Include concise comments and usage examples:\n\n$input"
                "refactor" -> "Refactor the following $language code for modern best practices, readability, modularity, and speed:\n\n```$language\n$input\n```"
                else -> "Generate comprehensive unit test suites for the following $language code:\n\n```$language\n$input\n```"
            }

            // Using gemini-3.1-pro-preview for complex coding tasks as specified in gemini-api skill
            when (val res = GeminiApiClient.generateContent(prompt, model = "gemini-3.1-pro-preview")) {
                is AIResult.Success -> _codingOutput.value = res.text
                is AIResult.MissingApiKey -> _codingOutput.value = "API key missing."
                is AIResult.Error -> _codingOutput.value = "Coding assistant error: ${res.message}"
            }
            _isCodingLoading.value = false
        }
    }

    // --- Image Studio Actions ---
    fun generateImage(prompt: String, style: String, aspectRatio: String) {
        if (prompt.isBlank()) return
        val fullPrompt = "$prompt, rendered in $style style, 8k resolution, highly detailed, masterwork digital art"

        if (!isApiKeyConfigured) {
            _imageStatusText.value = if (_language.value == AppLanguage.ARABIC)
                "⚠️ ميزة توليد الصور تعتمد على نموذج gemini-2.5-flash-image وتتطلب مفتاح API نشطاً. لا يتم استخدام صور وهمية عشوائية لضمان الجودة."
            else
                "⚠️ Live image generation calls gemini-2.5-flash-image and requires an active API key. Simulated images are omitted to maintain genuine integration."
            _imageOutputBase64.value = null
            return
        }

        viewModelScope.launch {
            _isImageLoading.value = true
            _imageStatusText.value = if (_language.value == AppLanguage.ARABIC) "جارِ إرسال الأمر إلى نموذج الصور..." else "Dispatching prompt to gemini-2.5-flash-image..."
            when (val res = GeminiApiClient.generateImage(fullPrompt, aspectRatio = aspectRatio)) {
                is AIResult.Success -> {
                    _imageOutputBase64.value = res.imageBase64
                    _imageStatusText.value = res.text
                }
                is AIResult.MissingApiKey -> {
                    _imageStatusText.value = "API key missing."
                }
                is AIResult.Error -> {
                    _imageStatusText.value = "Image generation error: ${res.message}"
                }
            }
            _isImageLoading.value = false
        }
    }
}
