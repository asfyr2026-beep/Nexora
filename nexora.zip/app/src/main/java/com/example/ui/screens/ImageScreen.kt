package com.example.ui.screens

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.NexoraStrings
import com.example.ui.theme.*

@Composable
fun ImageScreen(
    imageBase64: String?,
    statusText: String,
    isLoading: Boolean,
    language: AppLanguage,
    onGenerateImage: (String, String, String) -> Unit
) {
    val isAr = language == AppLanguage.ARABIC

    val styleOptions = listOf(
        "Cyberpunk Neon" to (if (isAr) "سايبربانك نيون" else "Cyberpunk Neon"),
        "Cinematic 8K" to (if (isAr) "سينمائي بدقة 8K" else "Cinematic 8K"),
        "Anime Fantasy" to (if (isAr) "أنمي خيالي" else "Anime Fantasy"),
        "3D Digital Art" to (if (isAr) "فن رقمي ثلاثي الأبعاد" else "3D Digital Art"),
        "Photorealistic" to (if (isAr) "واقعي كالصورة" else "Photorealistic"),
        "Minimalist Vector" to (if (isAr) "فيكتور تبسيطي" else "Minimalist Vector")
    )

    val aspectRatios = listOf(
        "1:1" to (if (isAr) "مربع 1:1" else "1:1 Square"),
        "16:9" to (if (isAr) "عريض 16:9" else "16:9 Wide"),
        "9:16" to (if (isAr) "طولي 9:16" else "9:16 Story"),
        "4:3" to (if (isAr) "كلاسيكي 4:3" else "4:3 Standard")
    )

    val sampleInspirations = if (isAr) listOf(
        "رائد فضاء يكتشف بلورة ضوئية على قمة جبل كوني",
        "مدينة ذكية متطورة مع سيارات طائرة وأضواء نيون زرقاء وبنفسجية",
        "مكتبة تاريخية تطفو في الفضاء مع كتب مضيئة ونجوم متلألئة",
        "روبوت ذكاء اصطناعي يساعد طفلاً في زراعة شجرة مضيئة"
    ) else listOf(
        "An astronaut discovering a glowing crystal core on an alien mountain",
        "Futuristic smart metropolis with flying vehicles and luminous blue and purple neon",
        "A celestial library drifting in deep space surrounded by glowing starlight",
        "An empathetic AI robot guiding a young scientist in planting a bioluminescent tree"
    )

    var promptInput by remember { mutableStateOf("") }
    var selectedStyle by remember { mutableStateOf("Cinematic 8K") }
    var selectedRatio by remember { mutableStateOf("1:1") }

    val decodedBitmap = remember(imageBase64) {
        if (!imageBase64.isNullOrBlank()) {
            try {
                val bytes = Base64.decode(imageBase64, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
            } catch (e: Exception) {
                null
            }
        } else null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Engine Info Badge
        Surface(
            color = NexoraSurfaceVariant,
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(imageVector = Icons.Default.Palette, contentDescription = null, tint = NexoraAmber, modifier = Modifier.size(24.dp))
                Column {
                    Text(
                        text = if (isAr) "محرك الصور: gemini-2.5-flash-image" else "Engine: gemini-2.5-flash-image",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraAmber
                        )
                    )
                    Text(
                        text = if (isAr) "توليد صور واقعية ورقمية بدقة فائقة مباشرة عبر واجهة برمجة Gemini." else "Direct high-fidelity visual synthesis via official Gemini multimodal endpoints.",
                        style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextSecondary)
                    )
                }
            }
        }

        // Style Selector Chips
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = if (isAr) "النمط البصري:" else "Visual Style:",
                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(styleOptions) { (key, label) ->
                    val isSelected = selectedStyle == key
                    Surface(
                        color = if (isSelected) NexoraAmber.copy(alpha = 0.25f) else NexoraSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) NexoraAmber else NexoraCardBorder
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedStyle = key }
                    ) {
                        Text(
                            text = label,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) NexoraAmber else NexoraTextSecondary
                            )
                        )
                    }
                }
            }
        }

        // Aspect Ratio Selector
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = if (isAr) "أبعاد الصورة:" else "Aspect Ratio:",
                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(aspectRatios) { (key, label) ->
                    val isSelected = selectedRatio == key
                    Surface(
                        color = if (isSelected) NexoraBluePrimary.copy(alpha = 0.25f) else NexoraSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) NexoraBluePrimary else NexoraCardBorder
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedRatio = key }
                    ) {
                        Text(
                            text = label,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) NexoraBlueGlow else NexoraTextSecondary
                            )
                        )
                    }
                }
            }
        }

        // Prompt Input
        OutlinedTextField(
            value = promptInput,
            onValueChange = { promptInput = it },
            placeholder = {
                Text(
                    text = NexoraStrings.imagePromptPlaceholder(language),
                    style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("image_prompt_input"),
            minLines = 3,
            maxLines = 6,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = NexoraSurfaceVariant,
                unfocusedContainerColor = NexoraSurfaceVariant,
                focusedBorderColor = NexoraAmber,
                unfocusedBorderColor = NexoraCardBorder,
                focusedTextColor = NexoraTextPrimary,
                unfocusedTextColor = NexoraTextPrimary
            )
        )

        // Generate Action Button
        Button(
            onClick = {
                if (promptInput.isNotBlank()) {
                    onGenerateImage(promptInput, selectedStyle, selectedRatio)
                }
            },
            enabled = promptInput.isNotBlank() && !isLoading,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("image_generate_button"),
            colors = ButtonDefaults.buttonColors(containerColor = NexoraAmber),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    color = Color.Black,
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(NexoraStrings.processing(language), color = Color.Black, fontWeight = FontWeight.Bold)
            } else {
                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isAr) "توليد الصورة بالذكاء الاصطناعي" else "Synthesize Visual Art",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Image Output or Status Card
        if (decodedBitmap != null) {
            Surface(
                color = NexoraSurface,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        bitmap = decodedBitmap,
                        contentDescription = "Generated Art",
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 250.dp, max = 360.dp)
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                    if (statusText.isNotBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary)
                        )
                    }
                }
            }
        } else if (statusText.isNotBlank()) {
            Surface(
                color = NexoraSurface,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isAr) "حالة التوليد والملاحظات" else "Synthesis Status & Notice",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraAmber
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = NexoraTextPrimary,
                            lineHeight = 22.sp
                        )
                    )
                }
            }
        }

        // Prompt Inspiration Ideas
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = if (isAr) "أفكار إلهام للأوامر:" else "Prompt Inspirations:",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = NexoraTextPrimary
                )
            )

            sampleInspirations.forEach { inspiration ->
                Surface(
                    color = NexoraSurfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { promptInput = inspiration }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Lightbulb, contentDescription = null, tint = NexoraAmber, modifier = Modifier.size(16.dp))
                        Text(
                            text = inspiration,
                            style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary),
                            modifier = Modifier.weight(1f)
                        )
                        Icon(imageVector = Icons.Default.NorthWest, contentDescription = "Use", tint = NexoraTextMuted, modifier = Modifier.size(14.dp))
                    }
                }
            }
        }
    }
}
