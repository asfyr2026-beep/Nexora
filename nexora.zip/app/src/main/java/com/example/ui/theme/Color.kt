package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Nexora Dark Theme Palette - Deep Obsidian & Radiant Blue/Purple
val NexoraDarkBg = Color(0xFF0B0F19)
val NexoraSurface = Color(0xFF111827)
val NexoraSurfaceVariant = Color(0xFF1E2638)
val NexoraCardBorder = Color(0xFF2E3B52)

val NexoraBluePrimary = Color(0xFF3B82F6)
val NexoraBlueGlow = Color(0xFF60A5FA)
val NexoraBlueContainer = Color(0xFF1E3A8A)

val NexoraPurpleSecondary = Color(0xFF8B5CF6)
val NexoraPurpleGlow = Color(0xFFA855F7)
val NexoraPurpleContainer = Color(0xFF4C1D95)

val NexoraCyanAccent = Color(0xFF06B6D4)
val NexoraEmerald = Color(0xFF10B981)
val NexoraAmber = Color(0xFFF59E0B)
val NexoraRose = Color(0xFFF43F5E)

val NexoraTextPrimary = Color(0xFFF8FAFC)
val NexoraTextSecondary = Color(0xFF94A3B8)
val NexoraTextMuted = Color(0xFF64748B)

val NexoraGlassBg = Color(0xD9161E2E)
