package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.NexoraStrings
import com.example.ui.theme.*

@Composable
fun CodingScreen(
    codingOutput: String,
    isLoading: Boolean,
    language: AppLanguage,
    onRunCodeAction: (String, String, String) -> Unit
) {
    val isAr = language == AppLanguage.ARABIC
    val context = LocalContext.current

    val programmingLanguages = listOf("Kotlin", "Python", "JavaScript", "TypeScript", "Rust", "Go", "SQL")

    val codeActions = listOf(
        "explain" to (if (isAr) "شرح وتفسير الكود" else "Explain Architecture"),
        "fix" to (if (isAr) "كشف وإصلاح الأخطاء" else "Debug & Fix"),
        "generate" to (if (isAr) "توليد كود برمجي" else "Generate Snippet"),
        "refactor" to (if (isAr) "تحسين وإعادة هيكلة" else "Refactor & Speed"),
        "tests" to (if (isAr) "كتابة اختبارات Unit Tests" else "Unit Test Suite")
    )

    var selectedLang by remember { mutableStateOf("Kotlin") }
    var selectedAction by remember { mutableStateOf("explain") }
    var codeInput by remember { mutableStateOf("") }

    val presetSnippets = if (isAr) listOf(
        "خوارزمية الفرز السريع QuickSort في Kotlin",
        "دالة بايثون لتحليل ملفات JSON واستخراج الإحصائيات",
        "كود استعلام SQL لحساب معدل المبيعات الشهري",
        "React Hook مخصص لجلب البيانات مع إدارة الأخطاء"
    ) else listOf(
        "Kotlin QuickSort algorithm with generic constraints",
        "Python script to parse JSON and calculate statistics",
        "SQL query for monthly sales aggregation and window functions",
        "Custom React Hook for debounced search API queries"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Engine Badge
        Surface(
            color = NexoraSurfaceVariant,
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(imageVector = Icons.Default.Code, contentDescription = null, tint = NexoraEmerald, modifier = Modifier.size(22.dp))
                Column {
                    Text(
                        text = if (isAr) "محرك البرمجة: gemini-3.1-pro-preview" else "Deep Reasoning: gemini-3.1-pro-preview",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraEmerald
                        )
                    )
                    Text(
                        text = if (isAr) "استدلال منطقي متقدم، كتابة كود إنتاجي، وتتبع أخطاء دقيق." else "High-tier code synthesis, algorithmic analysis, and vulnerability triage.",
                        style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextSecondary)
                    )
                }
            }
        }

        // Language Chips
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = if (isAr) "لغة البرمجة:" else "Target Language:",
                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(programmingLanguages) { langName ->
                    val isSelected = selectedLang == langName
                    Surface(
                        color = if (isSelected) NexoraEmerald.copy(alpha = 0.25f) else NexoraSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) NexoraEmerald else NexoraCardBorder
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedLang = langName }
                    ) {
                        Text(
                            text = langName,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) NexoraEmerald else NexoraTextSecondary
                            )
                        )
                    }
                }
            }
        }

        // Action Chips
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = if (isAr) "العملية المطلوبة:" else "AI Code Operation:",
                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(codeActions) { (actionKey, actionTitle) ->
                    val isSelected = selectedAction == actionKey
                    Surface(
                        color = if (isSelected) NexoraBluePrimary.copy(alpha = 0.25f) else NexoraSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) NexoraBluePrimary else NexoraCardBorder
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedAction = actionKey }
                    ) {
                        Text(
                            text = actionTitle,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) NexoraBlueGlow else NexoraTextSecondary
                            )
                        )
                    }
                }
            }
        }

        // Code / Prompt Input Area
        OutlinedTextField(
            value = codeInput,
            onValueChange = { codeInput = it },
            placeholder = {
                Text(
                    text = NexoraStrings.codePromptPlaceholder(language),
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = NexoraTextMuted,
                        fontFamily = FontFamily.Monospace
                    )
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("code_input_field"),
            minLines = 5,
            maxLines = 10,
            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF0D121F),
                unfocusedContainerColor = Color(0xFF0D121F),
                focusedBorderColor = NexoraEmerald,
                unfocusedBorderColor = NexoraCardBorder,
                focusedTextColor = NexoraTextPrimary,
                unfocusedTextColor = NexoraTextPrimary
            )
        )

        // Action Button
        Button(
            onClick = {
                if (codeInput.isNotBlank()) {
                    onRunCodeAction(codeInput, selectedLang, selectedAction)
                }
            },
            enabled = codeInput.isNotBlank() && !isLoading,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("coding_action_button"),
            colors = ButtonDefaults.buttonColors(containerColor = NexoraEmerald),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    color = Color.Black,
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(NexoraStrings.processing(language), color = Color.Black, fontWeight = FontWeight.Bold)
            } else {
                Icon(imageVector = Icons.Default.Terminal, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isAr) "تشغيل التحليل البرمجي" else "Execute AI Analysis",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Output Code Card
        if (codingOutput.isNotBlank()) {
            Surface(
                color = Color(0xFF080D1A),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFFEF4444)))
                            Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFFF59E0B)))
                            Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF10B981)))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Nexora Code Studio • $selectedLang",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = NexoraTextSecondary,
                                    fontFamily = FontFamily.Monospace
                                )
                            )
                        }

                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Nexora Code", codingOutput)
                                clipboard.setPrimaryClip(clip)
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = NexoraStrings.copy(language),
                                tint = NexoraTextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = NexoraCardBorder, modifier = Modifier.padding(vertical = 8.dp))

                    Text(
                        text = codingOutput,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFFE2E8F0),
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 20.sp
                        )
                    )
                }
            }
        }

        // Quick Idea Snippets
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = if (isAr) "نماذج وأمثلة برمجية سريعة:" else "Quick Algorithm Templates:",
                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
            )

            presetSnippets.forEach { snippet ->
                Surface(
                    color = NexoraSurfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { codeInput = snippet }
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.DataObject, contentDescription = null, tint = NexoraEmerald, modifier = Modifier.size(16.dp))
                        Text(
                            text = snippet,
                            style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}
