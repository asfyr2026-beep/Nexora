package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.NexoraStrings
import com.example.ui.FlashCardItem
import com.example.ui.theme.*

@Composable
fun StudyScreen(
    studyResult: String,
    flashcards: List<FlashCardItem>,
    isLoading: Boolean,
    language: AppLanguage,
    onRunStudy: (String, String) -> Unit
) {
    val isAr = language == AppLanguage.ARABIC
    val context = LocalContext.current

    var selectedMode by remember { mutableStateOf("flashcards") } // flashcards, summary, quiz, explain
    var topicInput by remember { mutableStateOf("") }
    var currentCardIndex by remember { mutableIntStateOf(0) }
    var isCardFlipped by remember { mutableStateOf(false) }

    val presetTopics = if (isAr) listOf(
        "الشبكات العصبية والتعلم العميق",
        "دورة كريبس وتنفس الخلية",
        "الاقتصاد الكلي والتضخم",
        "مبادئ تقنية النانو الحيوية"
    ) else listOf(
        "Neural Networks & Deep Learning",
        "Cellular Respiration & Krebs Cycle",
        "Macroeconomics & Inflation Dynamics",
        "CRISPR Cas9 Gene Editing"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Mode Selector Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(NexoraSurfaceVariant)
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val modes = listOf(
                "flashcards" to NexoraStrings.studyFlashcardsTab(language),
                "summary" to NexoraStrings.studySummaryTab(language),
                "quiz" to NexoraStrings.studyQuizTab(language),
                "explain" to NexoraStrings.studyExplainTab(language)
            )

            modes.forEach { (modeKey, modeTitle) ->
                val isSelected = selectedMode == modeKey
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) NexoraPurpleSecondary else Color.Transparent)
                        .clickable { selectedMode = modeKey }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = modeTitle,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else NexoraTextSecondary,
                            fontSize = 11.sp
                        ),
                        maxLines = 1,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Preset Topic Chips
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = if (isAr) "مواضيع مقترحة:" else "Suggested Subjects:",
                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(presetTopics) { topic ->
                    Surface(
                        color = NexoraSurface,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { topicInput = topic }
                    ) {
                        Text(
                            text = topic,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelSmall.copy(color = NexoraBlueGlow)
                        )
                    }
                }
            }
        }

        // Topic Input Area
        OutlinedTextField(
            value = topicInput,
            onValueChange = { topicInput = it },
            placeholder = {
                Text(
                    text = NexoraStrings.studyTopicPlaceholder(language),
                    style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("study_topic_input"),
            minLines = 3,
            maxLines = 6,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = NexoraSurfaceVariant,
                unfocusedContainerColor = NexoraSurfaceVariant,
                focusedBorderColor = NexoraPurpleSecondary,
                unfocusedBorderColor = NexoraCardBorder,
                focusedTextColor = NexoraTextPrimary,
                unfocusedTextColor = NexoraTextPrimary
            )
        )

        // Synthesize Button
        Button(
            onClick = {
                if (topicInput.isNotBlank()) {
                    isCardFlipped = false
                    currentCardIndex = 0
                    onRunStudy(topicInput, selectedMode)
                }
            },
            enabled = topicInput.isNotBlank() && !isLoading,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("study_synthesize_button"),
            colors = ButtonDefaults.buttonColors(containerColor = NexoraPurpleSecondary),
            shape = RoundedCornerShape(14.dp)
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    color = Color.White,
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(NexoraStrings.processing(language), fontWeight = FontWeight.Bold)
            } else {
                Icon(imageVector = Icons.Default.AutoStories, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isAr) "تحليل وتوليد المادة الدراسية" else "Synthesize Study Material",
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Result Display
        if (selectedMode == "flashcards" && flashcards.isNotEmpty()) {
            val totalCards = flashcards.size
            val card = flashcards[currentCardIndex.coerceIn(0, totalCards - 1)]

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isAr) "بطاقة ${currentCardIndex + 1} من $totalCards" else "Card ${currentCardIndex + 1} of $totalCards",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraPurpleGlow
                        )
                    )
                    Text(
                        text = if (isCardFlipped) (if (isAr) "الإجابة" else "Answer") else (if (isAr) "السؤال" else "Question"),
                        style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
                    )
                }

                // Interactive 3D Flip Card
                Surface(
                    color = if (isCardFlipped) NexoraPurpleContainer else NexoraSurfaceVariant,
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        2.dp,
                        if (isCardFlipped) NexoraPurpleGlow else NexoraBluePrimary.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 200.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { isCardFlipped = !isCardFlipped }
                        .testTag("flashcard_interactive_box")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isCardFlipped) NexoraPurpleGlow.copy(alpha = 0.2f) else NexoraBlueGlow.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = if (isCardFlipped) (if (isAr) "الإجابة النموذجية" else "ANSWER") else (if (isAr) "السؤال التعليمي" else "QUESTION"),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCardFlipped) NexoraPurpleGlow else NexoraBlueGlow
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = if (isCardFlipped) card.answer else card.question,
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = NexoraTextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                lineHeight = 26.sp
                            ),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = if (isAr) "اضغط على البطاقة لقلبها" else "Tap card to flip",
                            style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
                        )
                    }
                }

                // Flashcard Navigation Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    FilledTonalButton(
                        onClick = {
                            if (currentCardIndex > 0) {
                                isCardFlipped = false
                                currentCardIndex--
                            }
                        },
                        enabled = currentCardIndex > 0,
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = NexoraSurfaceVariant),
                        modifier = Modifier.testTag("flashcard_prev_button")
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isAr) "السابق" else "Previous")
                    }

                    FilledTonalButton(
                        onClick = {
                            if (currentCardIndex < totalCards - 1) {
                                isCardFlipped = false
                                currentCardIndex++
                            }
                        },
                        enabled = currentCardIndex < totalCards - 1,
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = NexoraSurfaceVariant),
                        modifier = Modifier.testTag("flashcard_next_button")
                    ) {
                        Text(if (isAr) "التالي" else "Next")
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        } else if (studyResult.isNotBlank()) {
            // Summary, Quiz, or Explanation Text Card
            Surface(
                color = NexoraSurface,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isAr) "المخرجات الدراسية" else "Synthesized Insights",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraPurpleGlow
                            )
                        )

                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Nexora Study Material", studyResult)
                                clipboard.setPrimaryClip(clip)
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = NexoraStrings.copy(language),
                                tint = NexoraTextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = NexoraCardBorder, modifier = Modifier.padding(vertical = 8.dp))

                    Text(
                        text = studyResult,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = NexoraTextPrimary,
                            lineHeight = 24.sp
                        )
                    )
                }
            }
        }
    }
}
