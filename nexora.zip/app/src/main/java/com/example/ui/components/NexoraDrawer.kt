package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.NexoraStrings
import com.example.ui.ScreenDestination
import com.example.ui.theme.*

data class NavItemSpec(
    val destination: ScreenDestination,
    val title: (AppLanguage) -> String,
    val icon: ImageVector,
    val tag: String,
    val badge: String? = null
)

@Composable
fun NexoraDrawerContent(
    currentDestination: ScreenDestination,
    language: AppLanguage,
    isApiKeyConfigured: Boolean,
    onNavigate: (ScreenDestination) -> Unit,
    onCloseDrawer: () -> Unit
) {
    val items = listOf(
        NavItemSpec(
            destination = ScreenDestination.LANDING,
            title = { NexoraStrings.navOverview(it) },
            icon = Icons.Default.Dashboard,
            tag = "nav_overview"
        ),
        NavItemSpec(
            destination = ScreenDestination.CHAT,
            title = { NexoraStrings.navChat(it) },
            icon = Icons.Default.ChatBubble,
            tag = "nav_chat",
            badge = "Gemini"
        ),
        NavItemSpec(
            destination = ScreenDestination.STUDY,
            title = { NexoraStrings.navStudy(it) },
            icon = Icons.Default.School,
            tag = "nav_study"
        ),
        NavItemSpec(
            destination = ScreenDestination.TRANSLATION,
            title = { NexoraStrings.navTranslate(it) },
            icon = Icons.Default.GTranslate,
            tag = "nav_translate"
        ),
        NavItemSpec(
            destination = ScreenDestination.WRITING,
            title = { NexoraStrings.navWriting(it) },
            icon = Icons.Default.EditNote,
            tag = "nav_writing"
        ),
        NavItemSpec(
            destination = ScreenDestination.IMAGE,
            title = { NexoraStrings.navImage(it) },
            icon = Icons.Default.Palette,
            tag = "nav_image",
            badge = "2.5"
        ),
        NavItemSpec(
            destination = ScreenDestination.CODING,
            title = { NexoraStrings.navCoding(it) },
            icon = Icons.Default.Code,
            tag = "nav_coding",
            badge = "3.1 Pro"
        ),
        NavItemSpec(
            destination = ScreenDestination.TASKS,
            title = { NexoraStrings.navTasks(it) },
            icon = Icons.Default.Checklist,
            tag = "nav_tasks"
        )
    )

    Surface(
        modifier = Modifier
            .fillMaxHeight()
            .widthIn(min = 280.dp, max = 320.dp),
        color = NexoraDarkBg
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(NexoraBluePrimary, NexoraPurpleSecondary)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "N",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 22.sp
                    )
                }

                Column {
                    Text(
                        text = NexoraStrings.appName(language),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = NexoraTextPrimary
                        )
                    )
                    Text(
                        text = "v2.0 Enterprise",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = NexoraBlueGlow,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            HorizontalDivider(color = NexoraCardBorder, modifier = Modifier.padding(bottom = 12.dp))

            // Navigation Items
            items.forEach { item ->
                val selected = currentDestination == item.destination
                val activeBg = if (selected) {
                    Brush.horizontalGradient(
                        listOf(
                            NexoraBluePrimary.copy(alpha = 0.25f),
                            NexoraPurpleSecondary.copy(alpha = 0.15f)
                        )
                    )
                } else {
                    Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(activeBg)
                        .then(
                            if (selected) Modifier.border(
                                1.dp,
                                NexoraBluePrimary.copy(alpha = 0.4f),
                                RoundedCornerShape(12.dp)
                            ) else Modifier
                        )
                        .clickable {
                            onNavigate(item.destination)
                            onCloseDrawer()
                        }
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                        .testTag(item.tag)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.title(language),
                            tint = if (selected) NexoraBlueGlow else NexoraTextSecondary,
                            modifier = Modifier.size(22.dp)
                        )

                        Text(
                            text = item.title(language),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = if (selected) NexoraTextPrimary else NexoraTextSecondary
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        if (item.badge != null) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (selected) NexoraPurpleSecondary.copy(alpha = 0.4f) else NexoraSurfaceVariant
                            ) {
                                Text(
                                    text = item.badge,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (selected) Color.White else NexoraTextMuted,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))
            Spacer(modifier = Modifier.height(16.dp))

            // Footer Card
            Surface(
                color = NexoraSurfaceVariant,
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isApiKeyConfigured) NexoraEmerald else NexoraAmber)
                        )
                        Text(
                            text = if (isApiKeyConfigured) "Gemini Engine Ready" else "API Key Setup Needed",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isApiKeyConfigured) NexoraEmerald else NexoraAmber
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Real-time Google Gemini inference with verified zero-mock mode.",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = NexoraTextMuted,
                            fontSize = 10.sp
                        )
                    )
                }
            }
        }
    }
}
