package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.NexoraStrings
import com.example.ui.theme.*

@Composable
fun WritingScreen(
    writingOutput: String,
    isLoading: Boolean,
    language: AppLanguage,
    onGenerate: (String, String, String, String) -> Unit
) {
    val isAr = language == AppLanguage.ARABIC
    val context = LocalContext.current

    val formatOptions = listOf(
        "Executive Email" to (if (isAr) "بريد إلكتروني تنفيذي" else "Executive Email"),
        "Blog Article" to (if (isAr) "مقال مدونة متكامل" else "Blog Article"),
        "Grammar Polish" to (if (isAr) "تدقيق لغوي وصياغة" else "Grammar Polish"),
        "Creative Story" to (if (isAr) "قصة إبداعية" else "Creative Story"),
        "Executive Summary" to (if (isAr) "ملخص تنفيذي" else "Executive Summary"),
        "Social Thread" to (if (isAr) "سلسلة تدوينات قصيرة" else "Social Thread")
    )

    val toneOptions = listOf(
        "Professional & Crisp" to (if (isAr) "مهني وموجز" else "Professional"),
        "Persuasive & Engaging" to (if (isAr) "مقنع ومحفز" else "Persuasive"),
        "Academic & Analytical" to (if (isAr) "أكاديمي وتحليلي" else "Academic"),
        "Friendly & Warm" to (if (isAr) "ودي ومرن" else "Friendly")
    )

    var selectedFormat by remember { mutableStateOf("Executive Email") }
    var selectedTone by remember { mutableStateOf("Professional & Crisp") }
    var audienceInput by remember { mutableStateOf(if (isAr) "المدراء والشركاء" else "Executives & Clients") }
    var topicInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Format Chips
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = if (isAr) "صيغة المحتوى:" else "Content Format:",
                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(formatOptions) { (key, label) ->
                    val isSelected = selectedFormat == key
                    Surface(
                        color = if (isSelected) Color(0xFFEC4899).copy(alpha = 0.25f) else NexoraSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) Color(0xFFEC4899) else NexoraCardBorder
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedFormat = key }
                    ) {
                        Text(
                            text = label,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color(0xFFF472B6) else NexoraTextSecondary
                            )
                        )
                    }
                }
            }
        }

        // Tone Chips
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = if (isAr) "النبرة والأسلوب:" else "Voice & Tone:",
                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(toneOptions) { (key, label) ->
                    val isSelected = selectedTone == key
                    Surface(
                        color = if (isSelected) NexoraPurpleSecondary.copy(alpha = 0.25f) else NexoraSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) NexoraPurpleSecondary else NexoraCardBorder
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedTone = key }
                    ) {
                        Text(
                            text = label,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) NexoraPurpleGlow else NexoraTextSecondary
                            )
                        )
                    }
                }
            }
        }

        // Audience Field
        OutlinedTextField(
            value = audienceInput,
            onValueChange = { audienceInput = it },
            label = {
                Text(
                    text = if (isAr) "الجمهور المستهدف" else "Target Audience",
                    style = MaterialTheme.typography.labelSmall
                )
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = NexoraSurfaceVariant,
                unfocusedContainerColor = NexoraSurfaceVariant,
                focusedBorderColor = Color(0xFFEC4899),
                unfocusedBorderColor = NexoraCardBorder,
                focusedTextColor = NexoraTextPrimary,
                unfocusedTextColor = NexoraTextPrimary
            )
        )

        // Topic / Input Draft
        OutlinedTextField(
            value = topicInput,
            onValueChange = { topicInput = it },
            placeholder = {
                Text(
                    text = NexoraStrings.writingTopicPlaceholder(language),
                    style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("writing_topic_input"),
            minLines = 4,
            maxLines = 8,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = NexoraSurfaceVariant,
                unfocusedContainerColor = NexoraSurfaceVariant,
                focusedBorderColor = Color(0xFFEC4899),
                unfocusedBorderColor = NexoraCardBorder,
                focusedTextColor = NexoraTextPrimary,
                unfocusedTextColor = NexoraTextPrimary
            )
        )

        // Generate Button
        Button(
            onClick = {
                if (topicInput.isNotBlank()) {
                    onGenerate(topicInput, selectedFormat, selectedTone, audienceInput)
                }
            },
            enabled = topicInput.isNotBlank() && !isLoading,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("writing_generate_button"),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEC4899)),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    color = Color.White,
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(NexoraStrings.processing(language), fontWeight = FontWeight.Bold)
            } else {
                Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isAr) "صياغة وتوليد النص" else "Craft & Compose",
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Writing Output
        if (writingOutput.isNotBlank()) {
            val words = writingOutput.split("\\s+".toRegex()).filter { it.isNotBlank() }.size
            val chars = writingOutput.length

            Surface(
                color = NexoraSurface,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isAr) "المسودة النهائية المكتملة" else "Polished Draft",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFF472B6)
                                )
                            )
                            Text(
                                text = if (isAr) "$words كلمة • $chars حرف" else "$words words • $chars characters",
                                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
                            )
                        }

                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Nexora Written Output", writingOutput)
                                clipboard.setPrimaryClip(clip)
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = NexoraStrings.copy(language),
                                tint = NexoraTextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = NexoraCardBorder, modifier = Modifier.padding(vertical = 8.dp))

                    Text(
                        text = writingOutput,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = NexoraTextPrimary,
                            lineHeight = 24.sp
                        )
                    )
                }
            }
        }
    }
}
