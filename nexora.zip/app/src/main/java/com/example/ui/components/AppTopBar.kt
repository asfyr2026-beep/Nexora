package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.NexoraStrings
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(
    title: String,
    currentLanguage: AppLanguage,
    isApiKeyConfigured: Boolean,
    onMenuClick: () -> Unit,
    onLanguageToggle: () -> Unit,
    onApiKeyClick: () -> Unit
) {
    TopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(NexoraBluePrimary, NexoraPurpleSecondary)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "N",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp
                    )
                }
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                    Text(
                        text = NexoraStrings.appTagline(currentLanguage),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = NexoraTextMuted,
                            fontSize = 10.sp
                        ),
                        maxLines = 1
                    )
                }
            }
        },
        navigationIcon = {
            IconButton(
                onClick = onMenuClick,
                modifier = Modifier.testTag("menu_drawer_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Open Sidebar Navigation",
                    tint = NexoraTextPrimary
                )
            }
        },
        actions = {
            // API Key Status Chip
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (isApiKeyConfigured) NexoraSurfaceVariant else Color(0x33F59E0B),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isApiKeyConfigured) NexoraEmerald.copy(alpha = 0.5f) else NexoraAmber
                ),
                modifier = Modifier
                    .padding(end = 6.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onApiKeyClick() }
                    .testTag("api_key_status_chip")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isApiKeyConfigured) NexoraEmerald else NexoraAmber)
                    )
                    Text(
                        text = if (isApiKeyConfigured) "Gemini Live" else "Key Setup",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = if (isApiKeyConfigured) NexoraEmerald else NexoraAmber,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            // Language Toggle Button (EN / العربية)
            FilledTonalButton(
                onClick = onLanguageToggle,
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = NexoraSurfaceVariant,
                    contentColor = NexoraBlueGlow
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier
                    .padding(end = 8.dp)
                    .defaultMinSize(minWidth = 48.dp, minHeight = 36.dp)
                    .testTag("language_toggle_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Translate,
                        contentDescription = "Switch Language",
                        modifier = Modifier.size(16.dp),
                        tint = NexoraBlueGlow
                    )
                    Text(
                        text = if (currentLanguage == AppLanguage.ENGLISH) "العربية" else "English",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = NexoraDarkBg,
            scrolledContainerColor = NexoraSurface
        )
    )
}
