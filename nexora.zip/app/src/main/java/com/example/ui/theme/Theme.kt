package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NexoraDarkColorScheme = darkColorScheme(
    primary = NexoraBluePrimary,
    onPrimary = Color.White,
    primaryContainer = NexoraBlueContainer,
    onPrimaryContainer = Color(0xFFDBEAFE),
    secondary = NexoraPurpleSecondary,
    onSecondary = Color.White,
    secondaryContainer = NexoraPurpleContainer,
    onSecondaryContainer = Color(0xFFEDE9FE),
    tertiary = NexoraCyanAccent,
    onTertiary = Color.Black,
    tertiaryContainer = Color(0xFF164E63),
    onTertiaryContainer = Color(0xFFCFFAFE),
    background = NexoraDarkBg,
    onBackground = NexoraTextPrimary,
    surface = NexoraSurface,
    onSurface = NexoraTextPrimary,
    surfaceVariant = NexoraSurfaceVariant,
    onSurfaceVariant = NexoraTextSecondary,
    outline = NexoraCardBorder,
    outlineVariant = Color(0xFF1F293D),
    error = NexoraRose,
    onError = Color.White
)

@Composable
fun NexoraTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NexoraDarkColorScheme,
        typography = Typography,
        content = content
    )
}
