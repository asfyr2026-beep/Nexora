package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.NexoraStrings
import com.example.ui.theme.*

@Composable
fun ApiKeyDialog(
    isOpen: Boolean,
    isKeyConfigured: Boolean,
    language: AppLanguage,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    val isAr = language == AppLanguage.ARABIC

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = NexoraBluePrimary),
                modifier = Modifier.testTag("api_dialog_close_button")
            ) {
                Text(if (isAr) "فهمت ذلك" else "Understood")
            }
        },
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.linearGradient(listOf(NexoraBluePrimary, NexoraPurpleSecondary))
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isKeyConfigured) Icons.Default.CheckCircle else Icons.Default.Key,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Text(
                text = if (isKeyConfigured)
                    (if (isAr) "اتصال Gemini نشط وموثّق" else "Gemini Live API Active")
                else
                    NexoraStrings.apiKeyRequiredTitle(language),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NexoraTextPrimary
                )
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    color = if (isKeyConfigured) Color(0x2210B981) else Color(0x22F59E0B),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isKeyConfigured) NexoraEmerald.copy(alpha = 0.4f) else NexoraAmber.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = if (isKeyConfigured) NexoraEmerald else NexoraAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = if (isKeyConfigured) {
                                if (isAr) "يتم إرسال الطلبات مباشرة إلى نماذج Google Gemini الرسمية."
                                else "Direct API connection verified. Requests route straight to Google Gemini."
                            } else {
                                if (isAr) "الردود الوهمية معطلة لضمان أمان ودقة المعالجة."
                                else "Simulated fake AI outputs are disabled to guarantee production reliability."
                            },
                            style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextPrimary)
                        )
                    }
                }

                Text(
                    text = if (isAr)
                        "تستخدم منصة نيكسورا نماذج الذكاء الاصطناعي الأحدث من Google:\n• gemini-3.5-flash للمحادثة والاستيعاب والترجمة والدراسة.\n• gemini-3.1-pro-preview للبرمجة والاستنتاج المنطقي المعقد.\n• gemini-2.5-flash-image لتوليد الصور الإبداعية."
                    else
                        "Nexora powers its AI suite via official Gemini models:\n• gemini-3.5-flash: Fast chat, study analysis, translation & writing.\n• gemini-3.1-pro-preview: Deep logical reasoning & coding assistant.\n• gemini-2.5-flash-image: High-fidelity image synthesis.",
                    style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary, lineHeight = 18.sp)
                )

                if (!isKeyConfigured) {
                    Surface(
                        color = NexoraSurfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = if (isAr) "كيفية ضبط المفتاح:" else "How to configure in AI Studio:",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraBlueGlow
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isAr)
                                    "1. افتح لوحة الأسرار (Secrets) في واجهة AI Studio.\n2. أضف المفتاح باسم GEMINI_API_KEY.\n3. سيتم حقنه تلقائياً في التطبيق بأمان."
                                else
                                    "1. Open the Secrets panel in AI Studio.\n2. Add GEMINI_API_KEY with your Google AI Studio key.\n3. It will automatically inject at runtime without hardcoding.",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = NexoraTextSecondary,
                                    lineHeight = 16.sp
                                )
                            )
                        }
                    }
                }
            }
        },
        containerColor = NexoraSurface,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.testTag("api_key_info_dialog")
    )
}
