package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.NexoraStrings
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TranslationScreen(
    translatedText: String,
    isTranslating: Boolean,
    language: AppLanguage,
    onTranslate: (String, String, String, String) -> Unit
) {
    val isAr = language == AppLanguage.ARABIC
    val context = LocalContext.current

    val languagesList = listOf("English", "Arabic", "Spanish", "French", "German", "Japanese", "Chinese", "Turkish")
    val toneList = listOf(
        "Professional" to (if (isAr) "مهني ورسمي" else "Professional"),
        "Conversational" to (if (isAr) "محادثة طبيعية" else "Conversational"),
        "Technical" to (if (isAr) "تقني متخصص" else "Technical"),
        "Academic" to (if (isAr) "أكاديمي وبحثي" else "Academic")
    )

    var sourceLang by remember { mutableStateOf("English") }
    var targetLang by remember { mutableStateOf("Arabic") }
    var selectedTone by remember { mutableStateOf("Professional") }
    var sourceText by remember { mutableStateOf("") }

    var expandedSourceDropdown by remember { mutableStateOf(false) }
    var expandedTargetDropdown by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Language Selector Row with Swap
        Surface(
            color = NexoraSurface,
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Source Language Box
                Box {
                    Surface(
                        color = NexoraSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { expandedSourceDropdown = true }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = sourceLang,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraTextPrimary
                                )
                            )
                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = NexoraBlueGlow)
                        }
                    }

                    DropdownMenu(
                        expanded = expandedSourceDropdown,
                        onDismissRequest = { expandedSourceDropdown = false }
                    ) {
                        languagesList.forEach { langName ->
                            DropdownMenuItem(
                                text = { Text(langName) },
                                onClick = {
                                    sourceLang = langName
                                    expandedSourceDropdown = false
                                }
                            )
                        }
                    }
                }

                // Swap Button
                IconButton(
                    onClick = {
                        val temp = sourceLang
                        sourceLang = targetLang
                        targetLang = temp
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(NexoraBluePrimary.copy(alpha = 0.2f))
                        .testTag("translation_swap_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.SwapHoriz,
                        contentDescription = NexoraStrings.swapLanguages(language),
                        tint = NexoraBlueGlow
                    )
                }

                // Target Language Box
                Box {
                    Surface(
                        color = NexoraSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { expandedTargetDropdown = true }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = targetLang,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraTextPrimary
                                )
                            )
                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = NexoraPurpleGlow)
                        }
                    }

                    DropdownMenu(
                        expanded = expandedTargetDropdown,
                        onDismissRequest = { expandedTargetDropdown = false }
                    ) {
                        languagesList.forEach { langName ->
                            DropdownMenuItem(
                                text = { Text(langName) },
                                onClick = {
                                    targetLang = langName
                                    expandedTargetDropdown = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Tone Selector
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = if (isAr) "نبرة وأسلوب الترجمة:" else "Translation Tone & Nuance:",
                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(toneList) { (toneKey, toneLabel) ->
                    val isSelected = selectedTone == toneKey
                    Surface(
                        color = if (isSelected) NexoraCyanAccent.copy(alpha = 0.2f) else NexoraSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) NexoraCyanAccent else NexoraCardBorder
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedTone = toneKey }
                    ) {
                        Text(
                            text = toneLabel,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) NexoraCyanAccent else NexoraTextSecondary
                            )
                        )
                    }
                }
            }
        }

        // Source Text Input
        OutlinedTextField(
            value = sourceText,
            onValueChange = { sourceText = it },
            placeholder = {
                Text(
                    text = NexoraStrings.translateSourcePlaceholder(language),
                    style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("translation_source_input"),
            minLines = 4,
            maxLines = 8,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = NexoraSurfaceVariant,
                unfocusedContainerColor = NexoraSurfaceVariant,
                focusedBorderColor = NexoraCyanAccent,
                unfocusedBorderColor = NexoraCardBorder,
                focusedTextColor = NexoraTextPrimary,
                unfocusedTextColor = NexoraTextPrimary
            )
        )

        // Translate Button
        Button(
            onClick = {
                if (sourceText.isNotBlank()) {
                    onTranslate(sourceText, sourceLang, targetLang, selectedTone)
                }
            },
            enabled = sourceText.isNotBlank() && !isTranslating,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("translate_action_button"),
            colors = ButtonDefaults.buttonColors(containerColor = NexoraCyanAccent),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (isTranslating) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    color = Color.Black,
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(NexoraStrings.processing(language), color = Color.Black, fontWeight = FontWeight.Bold)
            } else {
                Icon(imageVector = Icons.Default.Translate, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isAr) "ترجمة النص فورياً" else "Translate Now",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Translation Result Output
        if (translatedText.isNotBlank()) {
            Surface(
                color = NexoraSurface,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = NexoraStrings.translateResult(language),
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraCyanAccent
                                )
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = NexoraCyanAccent.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = targetLang,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = NexoraCyanAccent,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }

                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Nexora Translation", translatedText)
                                clipboard.setPrimaryClip(clip)
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = NexoraStrings.copy(language),
                                tint = NexoraTextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = NexoraCardBorder, modifier = Modifier.padding(vertical = 8.dp))

                    Text(
                        text = translatedText,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = NexoraTextPrimary,
                            lineHeight = 24.sp
                        )
                    )
                }
            }
        }
    }
}
