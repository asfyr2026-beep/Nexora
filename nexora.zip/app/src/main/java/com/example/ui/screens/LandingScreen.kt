package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.localization.AppLanguage
import com.example.localization.NexoraStrings
import com.example.ui.ScreenDestination
import com.example.ui.theme.*

data class FeatureCardSpec(
    val destination: ScreenDestination,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val badge: String,
    val gradientColors: List<Color>,
    val testTag: String
)

@Composable
fun LandingScreen(
    language: AppLanguage,
    isApiKeyConfigured: Boolean,
    onNavigate: (ScreenDestination) -> Unit,
    onQuickPrompt: (String) -> Unit
) {
    val isAr = language == AppLanguage.ARABIC

    val quickPrompts = if (isAr) listOf(
        "اشرح لي الحوسبة الكمومية بطريقة مبسطة",
        "صغ بريداً إلكترونياً احترافياً لطلب اجتماع استثماري",
        "اكتب كود Kotlin لربط واجهة برمجة تطبيقات مع Coroutines",
        "أنشئ خطة دراسية واختباراً لمفاهيم تعلم الآلة",
        "ترجم مقالاً تقنياً مع الحفاظ على المصطلحات الدقيقة"
    ) else listOf(
        "Explain quantum computing in simple terms",
        "Draft an executive investor pitch email",
        "Write a Kotlin Coroutines flow example",
        "Generate a flashcard study plan for Machine Learning",
        "Translate English technical specs to fluent Arabic"
    )

    val featureCards = listOf(
        FeatureCardSpec(
            destination = ScreenDestination.CHAT,
            title = if (isAr) "المحادثة الذكية التفاعلية" else "AI Chat Interface",
            description = if (isAr) "تواصل لحظي متعدد الجولات مدعوم بنموذج gemini-3.5-flash." else "Multi-turn intelligent conversation powered by gemini-3.5-flash.",
            icon = Icons.Default.ChatBubble,
            badge = "Gemini 3.5",
            gradientColors = listOf(NexoraBluePrimary, NexoraBlueGlow),
            testTag = "landing_card_chat"
        ),
        FeatureCardSpec(
            destination = ScreenDestination.STUDY,
            title = if (isAr) "المساعد الدراسي والاختبارات" else "Study Assistant",
            description = if (isAr) "بطاقات استذكار تفاعلية، ملخصات تنفيذية، واختبارات قياس الفهم." else "Interactive flip flashcards, executive summaries, and knowledge quizzes.",
            icon = Icons.Default.School,
            badge = if (isAr) "استذكار تفاعلي" else "Flashcards & Quiz",
            gradientColors = listOf(NexoraPurpleSecondary, NexoraPurpleGlow),
            testTag = "landing_card_study"
        ),
        FeatureCardSpec(
            destination = ScreenDestination.TRANSLATION,
            title = if (isAr) "الترجمة الذكية متعددة النبرات" else "Smart Translation",
            description = if (isAr) "ترجمة دقيقة تراعي السياق الثقافي والأسلوب الأكاديمي أو الرسمي." else "Nuance-aware translation across Arabic, English, and international languages.",
            icon = Icons.Default.Translate,
            badge = if (isAr) "عربي / إنجليزي" else "Bilingual Dual",
            gradientColors = listOf(NexoraCyanAccent, NexoraBluePrimary),
            testTag = "landing_card_translate"
        ),
        FeatureCardSpec(
            destination = ScreenDestination.WRITING,
            title = if (isAr) "استوديو الكتابة والصياغة" else "Writing Studio",
            description = if (isAr) "إنشاء وتدقيق رسائل الأعمال، المقالات، والقصص بنبرات متعددة." else "Executive emails, blogs, grammar polish, and tone refinement.",
            icon = Icons.Default.EditNote,
            badge = if (isAr) "صياغة تنفيذية" else "Pro Writer",
            gradientColors = listOf(Color(0xFFEC4899), NexoraPurpleSecondary),
            testTag = "landing_card_writing"
        ),
        FeatureCardSpec(
            destination = ScreenDestination.IMAGE,
            title = if (isAr) "استوديو الصور الإبداعية" else "Image Studio",
            description = if (isAr) "توليد وتخصيص الأوامر لنموذج الصور gemini-2.5-flash-image." else "Prompt craft, aspect ratios, and visual synthesis with gemini-2.5-flash-image.",
            icon = Icons.Default.Palette,
            badge = "2.5 Flash Image",
            gradientColors = listOf(NexoraAmber, Color(0xFFF97316)),
            testTag = "landing_card_image"
        ),
        FeatureCardSpec(
            destination = ScreenDestination.CODING,
            title = if (isAr) "مساعد البرمجة والاستدلال" else "Coding Assistant",
            description = if (isAr) "شرح الأكواد، كشف الأخطاء وإصلاحها بنموذج gemini-3.1-pro-preview." else "Code generation, deep reasoning & bug fixes with gemini-3.1-pro-preview.",
            icon = Icons.Default.Code,
            badge = "3.1 Pro Engine",
            gradientColors = listOf(NexoraEmerald, NexoraCyanAccent),
            testTag = "landing_card_coding"
        ),
        FeatureCardSpec(
            destination = ScreenDestination.TASKS,
            title = if (isAr) "إدارة المهام والأولويات" else "Task Management",
            description = if (isAr) "تنظيم متكامل للمهام مع تصنيف ذكي وقاعدة بيانات محلية سريعة." else "Structured to-do management with priority tags and Room local storage.",
            icon = Icons.Default.Checklist,
            badge = if (isAr) "قاعدة بيانات" else "Room Database",
            gradientColors = listOf(NexoraBluePrimary, NexoraPurpleSecondary),
            testTag = "landing_card_tasks"
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Hero Section
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = NexoraSurfaceVariant,
            border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(NexoraPurpleContainer.copy(alpha = 0.5f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = NexoraPurpleGlow,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = NexoraStrings.heroBadge(language),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = NexoraPurpleGlow,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = NexoraStrings.heroHeadline(language),
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = NexoraTextPrimary,
                        lineHeight = 32.sp
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = NexoraStrings.heroSub(language),
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = NexoraTextSecondary,
                        lineHeight = 22.sp
                    )
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { onNavigate(ScreenDestination.CHAT) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NexoraBluePrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("hero_launch_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChatBubble,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isAr) "بدء المحادثة" else "Start AI Chat",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = { onNavigate(ScreenDestination.TASKS) },
                        border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("hero_open_tasks_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Checklist,
                            contentDescription = null,
                            tint = NexoraBlueGlow,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isAr) "المهام" else "My Tasks",
                            color = NexoraTextPrimary
                        )
                    }
                }
            }
        }

        // Quick Prompts Row
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = null,
                    tint = NexoraAmber,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = NexoraStrings.quickPromptsTitle(language),
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = NexoraTextPrimary
                    )
                )
            }

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(quickPrompts) { prompt ->
                    Surface(
                        color = NexoraSurfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onQuickPrompt(prompt) }
                            .testTag("quick_prompt_chip")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = prompt,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = NexoraTextPrimary,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = NexoraBlueGlow,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        // Specialized AI Modules Section
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                text = NexoraStrings.modulesTitle(language),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NexoraTextPrimary
                )
            )

            featureCards.forEach { card ->
                Surface(
                    color = NexoraSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NexoraCardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onNavigate(card.destination) }
                        .testTag(card.testTag)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brush.linearGradient(card.gradientColors)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = card.icon,
                                contentDescription = card.title,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = card.title,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = NexoraTextPrimary
                                    )
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = card.gradientColors.first().copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = card.badge,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = card.gradientColors.first(),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = card.description,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = NexoraTextSecondary,
                                    lineHeight = 16.sp
                                )
                            )
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Open",
                            tint = NexoraBlueGlow,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
